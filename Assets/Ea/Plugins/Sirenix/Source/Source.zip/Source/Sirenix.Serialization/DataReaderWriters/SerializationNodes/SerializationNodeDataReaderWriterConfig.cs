//-----------------------------------------------------------------------
// <copyright file="SerializationNodeDataReaderWriterConfig.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Serialization
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public static class SerializationNodeDataReaderWriterConfig
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        public const string NodeIdSeparator = "|";
    }
}