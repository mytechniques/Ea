#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="GeneralDrawerConfig.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor
{
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using UnityEditor;
    using UnityEngine;
    using UnityEngine.Serialization;

    /// <summary>
    /// <para>Contains general configuration for all Odin drawers.</para>
    /// <para>
    /// You can modify the configuration in the Odin Preferences window found in 'Window -> Odin Inspector -> Preferences -> Drawers -> General',
    /// or by locating the configuration file stored as a serialized object in the Sirenix folder under 'Odin Inspector/Config/Editor/GeneralDrawerConfig'.
    /// </para>
    /// </summary>
    [InitializeOnLoad]
    [SirenixEditorConfig("Odin Inspector/Drawers/General")]
    public class GeneralDrawerConfig : GlobalConfig<GeneralDrawerConfig>
    {
        [HideInInspector, SerializeField, FormerlySerializedAs("ShowMonoScriptInEditor")] private bool showMonoScriptInEditor = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("ExpandFoldoutByDefault")] private bool expandFoldoutByDefault = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("HideFoldoutWhileEmpty")] private bool hideFoldoutWhileEmpty = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("OpenListsByDefault")] private bool openListsByDefault = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("ShowItemCount")] private bool showItemCount = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("NumberOfItemsPrPage")] private int numberOfItemsPrPage = 15;
        [HideInInspector, SerializeField, FormerlySerializedAs("HidePagingWhileCollapsed")] private bool hidePagingWhileCollapsed = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("HidePagingWhileOnlyOnePage")] private bool hidePagingWhileOnlyOnePage = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("ShowExpandButton")] private bool showExpandButton = true;
        [HideInInspector, SerializeField, FormerlySerializedAs("QuaternionDrawMode")] private QuaternionDrawMode quaternionDrawMode = QuaternionDrawMode.Eulers;

        private bool prefsAreLoaded;

#pragma warning disable 0414

        [TitleGroup("Lists")]
        [Space(15)]
        [NonSerialized, ShowInInspector, PropertyOrder(2)]
        private List<int> exampleList = new List<int>();

#pragma warning restore 0414

        /// <summary>
        /// If set to true, most foldouts throughout the inspector will be expanded by default.
        /// </summary>
        [TitleGroup("Foldout", indent: false)]
        [ShowInInspector]
        [PropertyTooltip("If set to true, most foldouts throughout the inspector will be expanded by default.")]
        public bool ExpandFoldoutByDefault
        {
            get { return this.expandFoldoutByDefault; }
            set
            {
                this.expandFoldoutByDefault = value;
                SirenixEditorGUI.ExpandFoldoutByDefault = value;
                EditorPrefs.SetBool("SirenixEditorGUI.ExpandFoldoutByDefault", value);
            }
        }

        /// <summary>
        /// Specify the animation speed for most foldouts throughout the inspector.
        /// </summary>
        [TitleGroup("Animations", indent: false)]
        [ShowInInspector]
        [PropertyRange(0.001f, 4f)]
        [PropertyTooltip("Specify the animation speed for most foldouts throughout the inspector.")]
        public float GUIFoldoutAnimationDuration
        {
            get { return SirenixEditorGUI.DefaultFadeGroupDuration; }
            set { SirenixEditorGUI.DefaultFadeGroupDuration = value; }
        }

        /// <summary>
        /// Specify whether or not a list should hide the foldout triangle when the list is empty.
        /// </summary>
        [TitleGroup("Lists", indent: false)]
        [PropertyOrder(1)]
        [PropertyTooltip("Specifies whether or not a list should hide the foldout triangle when the list is empty.")]
        public bool HideFoldoutWhileEmpty
        {
            get { return this.hideFoldoutWhileEmpty; }
            set
            {
                this.hideFoldoutWhileEmpty = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.HideFoldoutWhileEmpty", value);
            }
        }

        /// <summary>
        /// Specify whether or not lists should hide the paging buttons when the list is collapsed.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        [PropertyTooltip("Specify whether or not lists should hide the paging buttons when the list is collapsed.")]
        public bool HidePagingWhileCollapsed
        {
            get { return this.hidePagingWhileCollapsed; }
            set
            {
                this.hidePagingWhileCollapsed = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.HidePagingWhileCollapsed", value);
            }
        }

        /// <summary>
        /// Specify whether or not lists should hide the paging buttons when there is only one page.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        public bool HidePagingWhileOnlyOnePage
        {
            get { return this.hidePagingWhileOnlyOnePage; }
            set
            {
                this.hidePagingWhileOnlyOnePage = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.HidePagingWhileOnlyOnePage", value);
            }
        }

        /// <summary>
        /// Specify the number of elements drawn per page.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        [OnValueChanged("ResizeExampleList"), MaxValue(500), MinValue(2)]
        [PropertyTooltip("Specify the number of elements drawn per page.")]
        public int NumberOfItemsPrPage
        {
            get { return this.numberOfItemsPrPage; }
            set
            {
                this.numberOfItemsPrPage = value;
                EditorPrefs.SetInt("GeneralDrawerConfig.NumberOfItemsPrPage", value);
            }
        }

        /// <summary>
        /// Specify whether or not lists should be expanded or collapsed by default.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        [PropertyTooltip("Specify whether or not lists should be expanded or collapsed by default.")]
        public bool OpenListsByDefault
        {
            get { return this.openListsByDefault; }
            set
            {
                this.openListsByDefault = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.OpenListsByDefault", value);
            }
        }

        /// <summary>
        /// When <c>true</c> the component labels, for vector fields, will be hidden when the field is too narrow.
        /// </summary>
        [TitleGroup("Vectors", indent: false)]
        [ShowInInspector, PropertyTooltip("When on the component labels, for vector fields, will be hidden when the field is too narrow.\nThis allows more space for the actual component fields themselves.")]
        public bool ResponsiveVectorComponentFields
        {
            get { return SirenixEditorFields.ResponsiveVectorComponentFields; }
            set { SirenixEditorFields.ResponsiveVectorComponentFields = value; }
        }

        /// <summary>
        /// Specify how the Quaternion struct should be shown in the inspector.
        /// </summary>
        [TitleGroup("Vectors")]
        [EnumToggleButtons]
        [ShowInInspector, PropertyTooltip("Current mode for how quaternions are edited in the inspector.\n\nEuler: Rotations as yaw, pitch and roll.\n\nAngle axis: Rotations as a axis of rotation, and an angle of rotation around that axis.\n\nRaw: Directly edit the x, y, z and w components of a quaternion.")]
        public QuaternionDrawMode QuaternionDrawMode
        {
            get { return this.quaternionDrawMode; }
            set
            {
                this.quaternionDrawMode = value;
                EditorPrefs.SetInt("GeneralDrawerConfig.QuaternionDrawMode", (int)value);
            }
        }

        [BoxGroup("Vectors/Box", showLabel: false)]
        [PropertyOrder(int.MaxValue)]
        private Quaternion ExampleQuaternion;

        // TODO: Re-add when vector drawing is not broken
        //[BoxGroup("Vectors/Box")]
        //[PropertyOrder(int.MaxValue)]
        //private Vector3 ExampleVector;

        /// <summary>
        /// Specify the shaking duration for most shaking animations throughout the inspector.
        /// </summary>
        [TitleGroup("Animations")]
        [PropertyTooltip("Specify the shaking duration for most shaking animations throughout the inspector.")]
        [PropertyRange(0f, 4f)]
        public float ShakingAnimationDuration
        {
            get { return SirenixEditorGUI.ShakingAnimationDuration; }
            set { SirenixEditorGUI.ShakingAnimationDuration = value; }
        }

        /// <summary>
        /// Specify whether or not to include a button which expands the list, showing all pages at once.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        [PropertyTooltip("Specify whether or not to include a button which expands the list, showing all pages at once")]
        public bool ShowExpandButton
        {
            get { return this.showExpandButton; }
            set
            {
                this.showExpandButton = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.ShowExpandButton", value);
            }
        }

        /// <summary>
        /// Specify whether or not lists should show item count.
        /// </summary>
        [TitleGroup("Lists")]
        [PropertyOrder(1)]
        [PropertyTooltip("Specify whether or not lists should show item count.")]
        public bool ShowItemCount
        {
            get { return this.showItemCount; }
            set
            {
                this.showItemCount = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.ShowItemCount", value);
            }
        }

        /// <summary>
        /// Specify whether or not the script selector above components should be drawn.
        /// </summary>
        [TitleGroup("General", indent: false)]
        [ShowInInspector]
        [PropertyTooltip("Specify whether or not the script selector above components should be drawn")]
        public bool ShowMonoScriptInEditor
        {
            get { return this.showMonoScriptInEditor; }
            set
            {
                this.showMonoScriptInEditor = value;
                EditorPrefs.SetBool("GeneralDrawerConfig.ShowMonoScriptInEditor", value);
            }
        }

        /// <summary>
        /// Specify the animation speed for <see cref="Sirenix.OdinInspector.TabGroupAttribute"/>
        /// </summary>
        [TitleGroup("Animations")]
        [PropertyRange(0.001f, 4f)]
        public float TabPageSlideAnimationDuration
        {
            get { return SirenixEditorGUI.TabPageSlideAnimationDuration; }
            set { SirenixEditorGUI.TabPageSlideAnimationDuration = value; }
        }

        private void LoadEditorPrefs()
        {
            if (this.prefsAreLoaded)
            {
                return;
            }

            this.prefsAreLoaded = true;

            this.showMonoScriptInEditor = EditorPrefs.GetBool("GeneralDrawerConfig.ShowMonoScriptInEditor", this.showMonoScriptInEditor);
            this.expandFoldoutByDefault = EditorPrefs.GetBool("GeneralDrawerConfig.ExpandFoldoutByDefault", this.expandFoldoutByDefault);
            this.hideFoldoutWhileEmpty = EditorPrefs.GetBool("GeneralDrawerConfig.HideFoldoutWhileEmpty", this.hideFoldoutWhileEmpty);
            this.openListsByDefault = EditorPrefs.GetBool("GeneralDrawerConfig.OpenListsByDefault", this.openListsByDefault);
            this.showItemCount = EditorPrefs.GetBool("GeneralDrawerConfig.ShowItemCount", this.showItemCount);
            this.numberOfItemsPrPage = EditorPrefs.GetInt("GeneralDrawerConfig.NumberOfItemsPrPage", this.numberOfItemsPrPage);
            this.hidePagingWhileCollapsed = EditorPrefs.GetBool("GeneralDrawerConfig.HidePagingWhileCollapsed", this.hidePagingWhileCollapsed);
            this.hidePagingWhileOnlyOnePage = EditorPrefs.GetBool("GeneralDrawerConfig.HidePagingWhileOnlyOnePage", this.hidePagingWhileOnlyOnePage);
            this.showExpandButton = EditorPrefs.GetBool("GeneralDrawerConfig.ShowExpandButton", this.showExpandButton);
            this.quaternionDrawMode = (QuaternionDrawMode)EditorPrefs.GetInt("GeneralDrawerConfig.QuaternionDrawMode", (int)this.quaternionDrawMode);
        }

        private void ResizeExampleList()
        {
            this.exampleList = Enumerable.Range(0, Math.Max(10, (int)(this.NumberOfItemsPrPage * Mathf.PI))).ToList();
        }
    }
}
#endif